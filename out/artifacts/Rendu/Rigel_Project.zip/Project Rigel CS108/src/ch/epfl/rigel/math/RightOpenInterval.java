package ch.epfl.rigel.math;

import java.util.Locale;


/**
 * @author Jeremy Di Dio
 * @author Daniel Tavares
 */
public final class RightOpenInterval extends Interval {

    private RightOpenInterval(double a, double b){
        super(a, b);
    }

    /**
     *
     * @param low : lower bond of the interval
     * @param high : upper bond of the interval
     * @return a right open interval from low to high
     */
    public static RightOpenInterval of(double low, double high){
        if(low >= high) throw new IllegalArgumentException();
        return new RightOpenInterval(low, high);
    }

    /**
     *
     * @param size
     * @return return a right open interval centralized on 0 and of size size
     */
    public static RightOpenInterval symmetric(double size) {
        if (size <= 0) throw new IllegalArgumentException();
        return new RightOpenInterval(-(size / 2), size / 2);
    }

    /**
     *
     * @param v
     * @return the reduction of v on the right open interval
     */
    public double reduce(double v){
        // int value = Math.floor((v-this.low()) / this.size());
        return v - this.size() * Math.floor((v-this.low()) / this.size());
        //TODO
    }

    /**
     *
     * @return the interval in a string form
     */
    @Override
    public String toString() {
        return String.format(Locale.ROOT,
                "[%s, %s[", this.low(), this.high());
    }

    /**
     *
     * @param v
     * @return true if v is in the interval
     */
    @Override
    public boolean contains(double v) {
        //strict positive because right open interval
        if(v >= this.low() && v < this.high()){
            return true;
        }
        return false;
    }
}

package ch.epfl.rigel.math;

/**
 * @author Daniel Tavares Agostinho
 * @author Jeremy Di dio
 *
 * class that represents a polynomial function
 */
public final class Polynomial {

    private final double[] polynome;

    /**
     * constructor that initializes an empty array that stores the coefficients
     *
     * @param degree : desired degree of the polynomial function
     */
    private Polynomial(int degree){
        polynome = new double[degree];
    }

    /**
     * creates an array that stores the coefficients in decreasing order of the power
     *
     * @param coefficientN : first coefficient
     * @param coefficients : array of the other coefficients
     * @return : desired polynomial function with the given coefficients
     */
    public static Polynomial of(double coefficientN, double... coefficients) {
        if (coefficientN == 0) {
            throw new IllegalArgumentException("Le coefficient de degré n est 0.");
        } else {
            Polynomial toReturn = new Polynomial(coefficients.length+1);
            toReturn.polynome[0] = coefficientN;
            System.arraycopy(coefficients, 0, toReturn.polynome, 1, coefficients.length);
            return toReturn;
        }
    }

    /**
     * evaluates the polynomial function with the given value
     * @param x : desired value to evaluate the function
     * @return : result of the evaluation
     */
    public double at(double x){
        int degrePoly = (polynome.length-1);
        double constante = polynome[degrePoly];
        if(degrePoly == 0){
            return constante;
        }
        else{
            double toReturn = polynome[0]*x;
            for(int i = 1; i < degrePoly; i++){
                toReturn = ((toReturn + polynome[i])*x);
            }
            return (toReturn + constante);
        }

    }

    /**
     * writes the polynomial function
     * @return : string of the polynomial function
     */
    @Override
    public String toString() {
        String toReturn = "";
        int posLastCoef = (polynome.length-1);
        for(int i = 0; i <= posLastCoef; i++){
            if(i != posLastCoef && polynome[i] != 0){
                if(Math.abs(polynome[i]) != 1) {
                    toReturn += polynome[i] + "x";
                }
                else {
                    if(i == 0 && polynome[i] < 0){
                        toReturn += "-";
                    }
                    toReturn += "x";
                }
                if(posLastCoef - i != 1){
                    toReturn += "^" + (posLastCoef-i);
                }
                if(polynome[i+1] > 0){
                    toReturn += "+";
                }
            }
            else if (polynome[i] == 0 && posLastCoef == 0){
                toReturn += polynome[i];
            }
            else if(i == posLastCoef && polynome[i] != 0){
                toReturn += polynome[i];
            }
        }
        return toReturn;
    }

    @Override
    public boolean equals(Object o) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int hashCode() {
        throw new UnsupportedOperationException();
    }
}

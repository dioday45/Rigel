package ch.epfl.rigel.math;

import java.lang.Math;


/**
 * @author Daniel Tavares Agostinho
 * @author Jeremy Di Dio
 */
public final class Angle {

    public static final double TAU = (2*Math.PI);
    private static final double SEC_TO_DEG = (1.0/(60*60));
    private static final double HR_TO_RAD = (TAU/24);
    private static final double RAD_TO_HR = 1/HR_TO_RAD;

    private Angle() {};

    /**
     * normalizes the angle putting it in [0, TAU[
     *
     * @param rad : given angle in radian
     * @return : return the angle normalized in radian
     */
    public static double normalizePositive(double rad){
        return (rad - TAU*Math.floor((rad/TAU)));
    }

    /**
     * returns angle corresponding to the given seconds
     * @param sec : given seconds
     * @return : angle in radian corresponding to the seconds
     */
    public static double ofArcsec(double sec){ return Math.toRadians(sec*SEC_TO_DEG);}

    /**
     * returns the angle in radian corresponding to the given coordinates
     * in deg, min and sec
     * @param deg : given coordinate of the degrees
     * @param min : given coordinate of the minutes
     * @param sec : given coordinates of the seconds
     * @return : returns the angle in radian
     */
    public static double ofDMS(int deg, int min, double sec){
        if(min < 0 || min >= 60 || sec < 0 || sec >= 60){
            throw new IllegalArgumentException();
        }
        else {return(ofDeg(deg) + ofArcsec(60*min + sec));}
    }

    /**
     * converts from degrees to radians
     * @param deg : given angle in degrees
     * @return : converted angle in radians
     */
    public static double ofDeg(double deg){
        return Math.toRadians(deg);
    }

    /**
     * converts from radian to degrees
     * @param rad : given angle in radian
     * @return : converted angle
     */
    public static double toDeg(double rad){
        return Math.toDegrees(rad);
    }

    /**
     * converts from hours to radians
     * @param hr : given angle in hours
     * @return : converted angle in radian
     */
    public static double ofHr(double hr){
        return (hr*HR_TO_RAD);
    }

    /**
     * converts given angle from radian ton hours
     * @param rad : given angle in radian
     * @return : converted angle in hours
     */
    public static double toHr(double rad){
        return (rad*RAD_TO_HR);
    }




}

package ch.epfl.rigel.math;

import java.util.Locale;

/**
 * @author Jeremy Di Dio
 * @author Daniel Tavares
 */
public final class ClosedInterval extends Interval {

    /**
     *
     * @param a
     * @param b
     */
    private ClosedInterval(double a, double b){
        super(a, b);
    }

    /**
     *
     * @param low :lower bond of the interval
     * @param high : upper bond of the interval
     * @return a closed interval from low to high
     */
    public static ClosedInterval of(double low, double high){
        if(low >= high) throw new IllegalArgumentException();
        return new ClosedInterval(low, high);
    }

    /**
     *
     * @param size
     * @return return a closed interval centralized on 0 and of size size
     */
    public static ClosedInterval symmetric(double size) {
        if (size <= 0) throw new IllegalArgumentException();
        return new ClosedInterval(-(size / 2), size / 2);
    }

    /**
     *
     * @param v
     * @return the value of v after being in the clip function
     */
    public double clip(double v){
        if(v <= this.low()) return this.low();
        if(v >= this.high()) return this.high();
        return v;
    }


    /**
     *
     * @param v
     * @return true if v is in the interval
     */
    @Override
    public boolean contains(double v) {
        if(v >= this.low() && v <= this.high()){
            return true;
        }
        return false;
    }

    /**
     *
     * @return the interval in a string form
     */
    @Override
    public String toString() {
        return String.format(Locale.ROOT,
                "[%s, %s]", this.low(), this.high());
    }
}

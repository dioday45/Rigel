package ch.epfl.rigel;

import ch.epfl.rigel.math.Interval;

public final class Preconditions {

    private Preconditions() {};

    /**
     * Throws IllegalArgumentException if isTrue is false;
     *
     * @param isTrue : given argument to check
     */
    public static void checkArgument(boolean isTrue){
        if(!isTrue) { throw new IllegalArgumentException(); }
    }

    /**
     * Throws IllegalArgumentException if value isn't in the interval else returns
     * the value
     * @param interval : given interval to check if the value is in it.
     * @param value : given value to check if in the interval
     * @return value if in the interval
     */
    public static double checkInInterval(Interval interval, double value){
        if(!interval.contains(value)){
            throw new IllegalArgumentException();
        }
        else {
            return value;
        }
    }
}
